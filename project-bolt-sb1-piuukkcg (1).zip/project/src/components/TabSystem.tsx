import React from 'react';
import { ProcedureType } from '../types';

interface TabSystemProps {
  activeTab: ProcedureType;
  onTabChange: (tab: ProcedureType) => void;
}

const TabSystem: React.FC<TabSystemProps> = ({ activeTab, onTabChange }) => {
  return (
    <div className="flex mb-6">
      <button
        className={`px-6 py-3 font-medium transition-colors rounded-t-md ${
          activeTab === 'surgery'
            ? 'bg-blue-600 text-white'
            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
        }`}
        onClick={() => onTabChange('surgery')}
      >
        Ameliyat
      </button>
      <button
        className={`px-6 py-3 font-medium transition-colors rounded-t-md ${
          activeTab === 'endoColon'
            ? 'bg-blue-600 text-white'
            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
        }`}
        onClick={() => onTabChange('endoColon')}
      >
        Endo-Kolon
      </button>
    </div>
  );
};

export default TabSystem;