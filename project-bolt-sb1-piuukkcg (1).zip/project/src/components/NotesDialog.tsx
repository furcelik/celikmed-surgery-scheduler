import React from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { Procedure } from '../types';

interface NotesDialogProps {
  isOpen: boolean;
  onClose: () => void;
  procedure: Procedure;
}

const NotesDialog: React.FC<NotesDialogProps> = ({ isOpen, onClose, procedure }) => {
  return (
    <Dialog.Root open={isOpen} onOpenChange={onClose}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50" />
        <Dialog.Content className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg p-6 shadow-xl w-[500px]">
          <Dialog.Title className="text-lg font-semibold mb-4">
            {procedure.patientName} - Hasta Notları
          </Dialog.Title>
          <div className="mb-6">
            <p className="text-gray-600 whitespace-pre-wrap">
              {procedure.notes || 'Bu hasta için not bulunmamaktadır.'}
            </p>
          </div>
          <Dialog.Close asChild>
            <button className="absolute right-4 top-4 text-gray-400 hover:text-gray-600">
              <X size={18} />
            </button>
          </Dialog.Close>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
};

export default NotesDialog;