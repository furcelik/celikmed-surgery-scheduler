import React from 'react';
import { Stethoscope, Printer, LogOut } from 'lucide-react';
import { formatDate } from '../utils/dateUtils';

interface HeaderProps {
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogout }) => {
  const handlePrint = () => {
    const printContent = document.getElementById('printable-table')?.innerHTML;
    const currentDate = formatDate(new Date());
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>CelikMed - Hasta Listesi</title>
          <style>
            @media print {
              @page {
                size: A4 landscape;
                margin: 1.5cm;
              }
              body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
                line-height: 1.4;
                color: #111827;
              }
              .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 24px;
                padding-bottom: 16px;
                border-bottom: 2px solid #2563eb;
              }
              .logo-section {
                display: flex;
                align-items: center;
                gap: 12px;
              }
              .logo-section h1 {
                font-size: 24px;
                font-weight: bold;
                color: #2563eb;
                margin: 0;
              }
              .logo-section p {
                font-size: 14px;
                color: #6b7280;
                margin: 4px 0 0 0;
              }
              .date {
                font-size: 14px;
                color: #6b7280;
              }
              table {
                width: 100%;
                border-collapse: collapse;
                font-size: 12px;
              }
              th {
                background-color: #f3f4f6;
                color: #4b5563;
                font-weight: 600;
                text-align: left;
                padding: 8px 12px;
                border-bottom: 2px solid #e5e7eb;
              }
              td {
                padding: 8px 12px;
                border-bottom: 1px solid #e5e7eb;
              }
              tr:nth-child(even) {
                background-color: #f9fafb;
              }
              .no-print, 
              .print\\:hidden,
              th:last-child,
              td:last-child {
                display: none !important;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="logo-section">
              <h1>CelikMed</h1>
              <p>Hasta Takip Sistemi</p>
            </div>
            <div class="date">
              Tarih: ${currentDate}
            </div>
          </div>
          <div>
            ${printContent}
          </div>
        </body>
        </html>
      `);

      setTimeout(() => {
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
      }, 250);
    }
  };

  return (
    <header className="bg-blue-600 text-white p-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <Stethoscope size={32} className="text-white" />
          <div>
            <h1 className="text-2xl font-bold">CelikMed</h1>
            <p className="text-sm text-blue-100">Hasta Takip Sistemi</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <button 
            onClick={handlePrint}
            className="bg-white text-blue-600 px-4 py-2 rounded-md flex items-center space-x-2 transition-all hover:bg-blue-50"
          >
            <Printer size={18} />
            <span>Yazdır</span>
          </button>
          <button 
            onClick={onLogout}
            className="bg-blue-700 text-white px-4 py-2 rounded-md flex items-center space-x-2 transition-all hover:bg-blue-800"
          >
            <LogOut size={18} />
            <span>Çıkış Yap</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;