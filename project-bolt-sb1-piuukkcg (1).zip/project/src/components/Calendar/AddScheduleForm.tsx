import React, { useState } from 'react';
import { ProcedureFormData, ProcedureType, ENDO_PROCEDURES } from '../../types';
import { Plus } from 'lucide-react';

interface AddScheduleFormProps {
  type: ProcedureType;
  onAdd: (data: ProcedureFormData) => void;
}

const AddScheduleForm: React.FC<AddScheduleFormProps> = ({ type, onAdd }) => {
  const initialFormState: ProcedureFormData = {
    roomNumber: type === 'surgery' ? '' : undefined,
    doctor: '',
    procedureType: '',
    patientName: '',
    patientPhone: '',
    summary: '',
    notes: ''
  };

  const [formData, setFormData] = useState<ProcedureFormData>(initialFormState);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    setFormData(initialFormState);
  };

  const formatText = (text: string) => {
    const mdoMatch = text.match(/mdö|MDÖ|Mdö/i);
    const etikMatch = text.match(/etik|ETİK|Etik/i);
    const ybMatch = text.match(/yb|YB|Yb/i);

    if (mdoMatch) {
      return <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium bg-blue-50 text-blue-700 border border-blue-100 rounded">MDÖ</span>;
    }
    if (etikMatch) {
      return <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium bg-red-50 text-red-700 border border-red-100 rounded">ETİK</span>;
    }
    if (ybMatch) {
      return <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium bg-purple-50 text-purple-700 border border-purple-100 rounded">YB</span>;
    }
    return text;
  };

  return (
    <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-100">
      <div className="p-4 border-b border-gray-100">
        <h2 className="text-lg font-semibold text-gray-800">
          Yeni {type === 'surgery' ? 'Ameliyat' : 'İşlem'} Ekle
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          {type === 'surgery' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ameliyathane Odası
              </label>
              <input
                type="text"
                name="roomNumber"
                value={formData.roomNumber}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Doktor
            </label>
            <input
              type="text"
              name="doctor"
              value={formData.doctor}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {type === 'surgery' ? 'Operasyon' : 'İşlem'} Türü
            </label>
            {type === 'surgery' ? (
              <input
                type="text"
                name="procedureType"
                value={formData.procedureType}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            ) : (
              <select
                name="procedureType"
                value={formData.procedureType}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs"
              >
                <option value="">İşlem Seçiniz</option>
                {Object.keys(ENDO_PROCEDURES).map((procedure) => (
                  <option key={procedure} value={procedure}>
                    {procedure}
                  </option>
                ))}
              </select>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Hasta Adı
            </label>
            <input
              type="text"
              name="patientName"
              value={formData.patientName}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              İletişim Bilgisi
            </label>
            <input
              type="tel"
              name="patientPhone"
              value={formData.patientPhone}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Özet Bilgi
            </label>
            <input
              type="text"
              name="summary"
              value={formData.summary}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notlar
            </label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              maxLength={300}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center space-x-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors"
          >
            <Plus size={18} />
            <span>{type === 'surgery' ? 'Ameliyat' : 'İşlem'} Ekle</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddScheduleForm;