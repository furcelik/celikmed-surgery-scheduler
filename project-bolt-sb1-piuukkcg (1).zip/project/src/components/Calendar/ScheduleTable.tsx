import React, { useState } from 'react';
import { Procedure, ProcedureType, ENDO_PROCEDURES } from '../../types';
import { Trash2 } from 'lucide-react';
import DeleteConfirmDialog from '../DeleteConfirmDialog';
import NotesDialog from '../NotesDialog';

interface ScheduleTableProps {
  procedures: Procedure[];
  type: ProcedureType;
  onDelete: (id: string) => void;
}

const ScheduleTable: React.FC<ScheduleTableProps> = ({ procedures, type, onDelete }) => {
  const [selectedProcedure, setSelectedProcedure] = useState<Procedure | null>(null);
  const [isNotesOpen, setIsNotesOpen] = useState(false);

  if (procedures.length === 0) {
    return (
      <div className="bg-white rounded-md p-8 text-center text-gray-500 shadow-sm border border-gray-100">
        <p>Bu tarihte planlanmış {type === 'surgery' ? 'ameliyat' : 'endo-kolon işlemi'} bulunmamaktadır.</p>
      </div>
    );
  }

  const handleRowDoubleClick = (procedure: Procedure) => {
    setSelectedProcedure(procedure);
    setIsNotesOpen(true);
  };

  const formatText = (text: string) => {
    const mdoMatch = text.match(/mdö|MDÖ|Mdö/i);
    const etikMatch = text.match(/etik|ETİK|Etik/i);
    const ybMatch = text.match(/yb|YB|Yb/i);

    if (mdoMatch) {
      return <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium bg-blue-50 text-blue-700 border border-blue-100 rounded">MDÖ</span>;
    }
    if (etikMatch) {
      return <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium bg-red-50 text-red-700 border border-red-100 rounded">ETİK</span>;
    }
    if (ybMatch) {
      return <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium bg-purple-50 text-purple-700 border border-purple-100 rounded">YB</span>;
    }
    return text;
  };

  const renderCellContent = (text: string) => {
    const words = text.split(/\s+/);
    return words.map((word, index) => {
      const formattedWord = formatText(word);
      return (
        <React.Fragment key={index}>
          {index > 0 && ' '}
          {formattedWord}
        </React.Fragment>
      );
    });
  };

  return (
    <div className="bg-white rounded-md shadow-sm overflow-x-auto border border-gray-100" id="printable-table">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            {type === 'surgery' && (
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Oda No
              </th>
            )}
            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Doktor
            </th>
            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              {type === 'surgery' ? 'Operasyon' : 'İşlem'} Türü
            </th>
            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Hasta Adı
            </th>
            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Hasta Tel
            </th>
            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Özet Bilgi
            </th>
            <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider print:hidden">
              İşlemler
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {procedures.map((procedure) => (
            <tr 
              key={procedure.id} 
              className="hover:bg-gray-50 transition-colors cursor-pointer"
              onDoubleClick={() => handleRowDoubleClick(procedure)}
            >
              {type === 'surgery' && (
                <td className="px-4 py-2 whitespace-nowrap text-xs text-gray-900">
                  {procedure.roomNumber}
                </td>
              )}
              <td className="px-4 py-2 whitespace-nowrap text-xs text-gray-900">
                {renderCellContent(procedure.doctor)}
              </td>
              <td className="px-4 py-2 whitespace-nowrap text-xs">
                {type === 'endoColon' && procedure.procedureType in ENDO_PROCEDURES ? (
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ENDO_PROCEDURES[procedure.procedureType as keyof typeof ENDO_PROCEDURES]}`}>
                    {procedure.procedureType}
                  </span>
                ) : (
                  renderCellContent(procedure.procedureType)
                )}
              </td>
              <td className="px-4 py-2 whitespace-nowrap text-xs text-gray-900">
                {renderCellContent(procedure.patientName)}
              </td>
              <td className="px-4 py-2 whitespace-nowrap text-xs text-gray-900">
                {procedure.patientPhone}
              </td>
              <td className="px-4 py-2 whitespace-nowrap text-xs text-gray-900">
                {renderCellContent(procedure.summary)}
              </td>
              <td className="px-4 py-2 whitespace-nowrap text-right text-xs font-medium print:hidden">
                <div className="flex justify-end">
                  <DeleteConfirmDialog onConfirm={() => onDelete(procedure.id)}>
                    <button className="text-red-500 hover:text-red-700 transition-colors p-1 hover:bg-red-50 rounded">
                      <Trash2 size={16} />
                    </button>
                  </DeleteConfirmDialog>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {selectedProcedure && (
        <NotesDialog 
          isOpen={isNotesOpen} 
          onClose={() => setIsNotesOpen(false)} 
          procedure={selectedProcedure} 
        />
      )}
    </div>
  );
};

export default ScheduleTable;