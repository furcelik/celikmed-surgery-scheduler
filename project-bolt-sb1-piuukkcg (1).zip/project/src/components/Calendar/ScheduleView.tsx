import React from 'react';
import { Procedure, ProcedureFormData, ProcedureType } from '../../types';
import ScheduleTable from './ScheduleTable';
import AddScheduleForm from './AddScheduleForm';

interface ScheduleViewProps {
  procedures: Procedure[];
  currentType: ProcedureType;
  onAddProcedure: (data: ProcedureFormData) => void;
  onDeleteProcedure: (id: string) => void;
}

const ScheduleView: React.FC<ScheduleViewProps> = ({
  procedures,
  currentType,
  onAddProcedure,
  onDeleteProcedure
}) => {
  return (
    <div className="space-y-6">
      <ScheduleTable 
        procedures={procedures} 
        type={currentType} 
        onDelete={onDeleteProcedure}
      />
      <AddScheduleForm 
        type={currentType} 
        onAdd={onAddProcedure} 
      />
    </div>
  );
};

export default ScheduleView;