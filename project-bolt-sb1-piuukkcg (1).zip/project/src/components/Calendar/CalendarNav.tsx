import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { formatDate, isHoliday } from '../../utils/dateUtils';

interface CalendarNavProps {
  currentDate: Date;
  onPrevDay: () => void;
  onNextDay: () => void;
  onDateChange: (date: Date) => void;
}

const CalendarNav: React.FC<CalendarNavProps> = ({
  currentDate,
  onPrevDay,
  onNextDay,
  onDateChange
}) => {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [viewMonth, setViewMonth] = useState(currentDate.getMonth());
  const [viewYear, setViewYear] = useState(currentDate.getFullYear());

  const handleDateSelect = (date: Date) => {
    onDateChange(date);
    setIsCalendarOpen(false);
  };

  const generateCalendarDays = (year: number, month: number) => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const days = [];
    const startDay = firstDay.getDay() || 7; // Convert Sunday (0) to 7

    // Add empty cells for days before the first day of the month
    for (let i = 1; i < startDay; i++) {
      days.push(null);
    }

    // Add days of the month
    for (let i = 1; i <= lastDay.getDate(); i++) {
      days.push(new Date(year, month, i));
    }

    return days;
  };

  const weekDays = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
  const months = [
    'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
    'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
  ];

  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
  };

  const isSelected = (date: Date) => {
    return date.getDate() === currentDate.getDate() &&
           date.getMonth() === currentDate.getMonth() &&
           date.getFullYear() === currentDate.getFullYear();
  };

  const handlePrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(viewYear - 1);
    } else {
      setViewMonth(viewMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(viewYear + 1);
    } else {
      setViewMonth(viewMonth + 1);
    }
  };

  const getDateClassName = (date: Date) => {
    const holiday = isHoliday(date);
    let className = 'w-full h-full flex flex-col items-center justify-center rounded-full transition-colors relative ';

    if (isSelected(date)) {
      className += 'bg-blue-600 text-white font-medium ';
    } else if (isToday(date)) {
      className += 'bg-blue-50 text-blue-600 font-medium ';
    } else if (holiday) {
      switch (holiday.type) {
        case 'religious':
          className += 'bg-green-50 text-green-700 ';
          break;
        case 'national':
          className += 'bg-red-50 text-red-700 ';
          break;
        case 'special':
          className += 'bg-purple-50 text-purple-700 ';
          break;
      }
    } else {
      className += 'hover:bg-gray-100 text-gray-700 ';
    }

    return className;
  };

  return (
    <div className="flex items-center space-x-2 mb-4">
      <button
        onClick={onPrevDay}
        className="p-2 rounded-md hover:bg-gray-100 transition-colors"
        aria-label="Previous day"
      >
        <ChevronLeft size={20} />
      </button>
      
      <div className="relative">
        <button
          className="border border-gray-300 rounded-md px-4 py-2 flex items-center space-x-2 min-w-[150px] hover:bg-gray-50 transition-colors"
          onClick={() => setIsCalendarOpen(!isCalendarOpen)}
        >
          <span className="text-gray-700">{formatDate(currentDate)}</span>
          <Calendar size={18} className="text-gray-500" />
          {isHoliday(currentDate) && (
            <span className="ml-2 text-sm font-medium text-red-600">
              {isHoliday(currentDate)?.name}
            </span>
          )}
        </button>

        {isCalendarOpen && (
          <div className="absolute top-full mt-1 left-0 bg-white rounded-lg shadow-lg border border-gray-200 p-4 w-[300px] z-50">
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={handlePrevMonth}
                className="p-1 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
              <div className="flex items-center space-x-1">
                <select
                  value={viewMonth}
                  onChange={(e) => setViewMonth(parseInt(e.target.value))}
                  className="text-sm font-medium bg-transparent border-none cursor-pointer hover:text-blue-600 focus:outline-none"
                >
                  {months.map((month, index) => (
                    <option key={month} value={index}>{month}</option>
                  ))}
                </select>
                <select
                  value={viewYear}
                  onChange={(e) => setViewYear(parseInt(e.target.value))}
                  className="text-sm font-medium bg-transparent border-none cursor-pointer hover:text-blue-600 focus:outline-none"
                >
                  {Array.from({ length: 21 }, (_, i) => viewYear - 10 + i).map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
              <button
                onClick={handleNextMonth}
                className="p-1 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ChevronRight size={16} />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1 mb-2">
              {weekDays.map((day) => (
                <div key={day} className="text-center text-xs font-medium text-gray-500 py-1">
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
              {generateCalendarDays(viewYear, viewMonth).map((date, index) => (
                <div key={index} className="aspect-square">
                  {date ? (
                    <button
                      onClick={() => handleDateSelect(date)}
                      className={getDateClassName(date)}
                      title={isHoliday(date)?.name}
                    >
                      <span>{date.getDate()}</span>
                      {isHoliday(date) && (
                        <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-current" />
                      )}
                    </button>
                  ) : (
                    <span className="w-full h-full flex items-center justify-center text-gray-300">
                      {' '}
                    </span>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-gray-200">
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="flex items-center space-x-1">
                  <span className="w-3 h-3 rounded-full bg-red-50 border border-red-200"></span>
                  <span className="text-gray-600">Resmi Tatil</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="w-3 h-3 rounded-full bg-green-50 border border-green-200"></span>
                  <span className="text-gray-600">Dini Bayram</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="w-3 h-3 rounded-full bg-purple-50 border border-purple-200"></span>
                  <span className="text-gray-600">Özel Gün</span>
                </div>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-gray-200 flex justify-between">
              <button
                onClick={() => handleDateSelect(new Date())}
                className="text-sm text-blue-600 hover:text-blue-800 font-medium"
              >
                Bugün
              </button>
              <button
                onClick={() => setIsCalendarOpen(false)}
                className="text-sm text-gray-600 hover:text-gray-800 font-medium"
              >
                Kapat
              </button>
            </div>
          </div>
        )}
      </div>
      
      <button
        onClick={onNextDay}
        className="p-2 rounded-md hover:bg-gray-100 transition-colors"
        aria-label="Next day"
      >
        <ChevronRight size={20} />
      </button>
    </div>
  );
};

export default CalendarNav;