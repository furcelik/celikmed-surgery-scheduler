import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Header from './components/Header';
import TabSystem from './components/TabSystem';
import CalendarNav from './components/Calendar/CalendarNav';
import ScheduleView from './components/Calendar/ScheduleView';
import Login from './components/Login';
import { Procedure, ProcedureFormData, ProcedureType, User } from './types';
import { formatDate, getNextDay, getPrevDay } from './utils/dateUtils';
import { 
  loadProcedures, 
  saveProcedures, 
  getProceduresByDateAndType,
  addProcedure,
  removeProcedure
} from './utils/storageUtils';
import { login, logout, getUser, isAuthenticated } from './utils/authUtils';

function App() {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [activeTab, setActiveTab] = useState<ProcedureType>('surgery');
  const [procedures, setProcedures] = useState<Procedure[]>([]);
  const [filteredProcedures, setFilteredProcedures] = useState<Procedure[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [loginError, setLoginError] = useState<string>('');

  useEffect(() => {
    const currentUser = getUser();
    if (currentUser) {
      setUser(currentUser);
      setProcedures(loadProcedures());
    }
  }, []);

  useEffect(() => {
    const formattedDate = formatDate(currentDate);
    const filtered = getProceduresByDateAndType(procedures, formattedDate, activeTab);
    setFilteredProcedures(filtered);
  }, [currentDate, activeTab, procedures]);

  const handleLogin = (username: string, password: string) => {
    if (login(username, password)) {
      setUser(getUser());
      setProcedures(loadProcedures());
      setLoginError('');
    } else {
      setLoginError('Kullanıcı adı veya şifre hatalı');
    }
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setProcedures([]);
  };

  const handleDateChange = (date: Date) => {
    setCurrentDate(date);
  };

  const handleNextDay = () => {
    setCurrentDate(getNextDay(currentDate));
  };

  const handlePrevDay = () => {
    setCurrentDate(getPrevDay(currentDate));
  };

  const handleTabChange = (tab: ProcedureType) => {
    setActiveTab(tab);
  };

  const handleAddProcedure = (formData: ProcedureFormData) => {
    const newProcedure: Procedure = {
      id: uuidv4(),
      date: formatDate(currentDate),
      ...formData
    };
    
    const updatedProcedures = addProcedure(procedures, newProcedure);
    setProcedures(updatedProcedures);
  };

  const handleDeleteProcedure = (id: string) => {
    const updatedProcedures = removeProcedure(procedures, id);
    setProcedures(updatedProcedures);
  };

  if (!isAuthenticated()) {
    return <Login onLogin={handleLogin} error={loginError} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header onLogout={handleLogout} />
      
      <main className="flex-1 container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="bg-white shadow-sm rounded-lg p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <CalendarNav
              currentDate={currentDate}
              onPrevDay={handlePrevDay}
              onNextDay={handleNextDay}
              onDateChange={handleDateChange}
            />
          </div>
          
          <TabSystem activeTab={activeTab} onTabChange={handleTabChange} />
          
          <ScheduleView
            procedures={filteredProcedures}
            currentType={activeTab}
            onAddProcedure={handleAddProcedure}
            onDeleteProcedure={handleDeleteProcedure}
          />
        </div>
      </main>
    </div>
  );
}

export default App;