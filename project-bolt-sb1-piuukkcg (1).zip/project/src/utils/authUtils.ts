import { User } from '../types';

const STORAGE_KEY = 'celikMedAuth';

export const login = (username: string, password: string): boolean => {
  // Bu örnek için sabit kullanıcı adı ve şifre kullanıyoruz
  // Gerçek uygulamada bu bilgiler güvenli bir şekilde saklanmalı
  if (username === 'admin@celikmed.com' && password === 'celikmed2025') {
    const user: User = {
      username,
      isAuthenticated: true
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    return true;
  }
  return false;
};

export const logout = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};

export const getUser = (): User | null => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    return JSON.parse(stored);
  }
  return null;
};

export const isAuthenticated = (): boolean => {
  const user = getUser();
  return user?.isAuthenticated ?? false;
};