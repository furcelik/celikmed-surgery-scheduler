export const formatDate = (date: Date): string => {
  return date.toLocaleDateString('tr-TR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
};

export const parseDate = (dateString: string): Date => {
  const [day, month, year] = dateString.split('.');
  return new Date(`${year}-${month}-${day}`);
};

export const getNextDay = (date: Date): Date => {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  return nextDay;
};

export const getPrevDay = (date: Date): Date => {
  const prevDay = new Date(date);
  prevDay.setDate(prevDay.getDate() - 1);
  return prevDay;
};

interface Holiday {
  date: string; // "DD.MM"
  name: string;
  type: 'religious' | 'national' | 'special';
}

export const getTurkishHolidays = (year: number): Holiday[] => {
  return [
    // Dini Bayramlar (2024 için sabit tarihler - her yıl değişir)
    { date: "10.04", name: "Ramazan Bayramı", type: "religious" },
    { date: "11.04", name: "Ramazan Bayramı", type: "religious" },
    { date: "12.04", name: "Ramazan Bayramı", type: "religious" },
    { date: "17.06", name: "Kurban Bayramı", type: "religious" },
    { date: "18.06", name: "Kurban Bayramı", type: "religious" },
    { date: "19.06", name: "Kurban Bayramı", type: "religious" },
    { date: "20.06", name: "Kurban Bayramı", type: "religious" },
    
    // Resmi Tatiller
    { date: "01.01", name: "Yılbaşı", type: "national" },
    { date: "23.04", name: "Ulusal Egemenlik ve Çocuk Bayramı", type: "national" },
    { date: "01.05", name: "Emek ve Dayanışma Günü", type: "national" },
    { date: "19.05", name: "Atatürk'ü Anma, Gençlik ve Spor Bayramı", type: "national" },
    { date: "15.07", name: "Demokrasi ve Milli Birlik Günü", type: "national" },
    { date: "30.08", name: "Zafer Bayramı", type: "national" },
    { date: "29.10", name: "Cumhuriyet Bayramı", type: "national" },
    
    // Özel Günler
    { date: "08.03", name: "Dünya Kadınlar Günü", type: "special" },
    { date: "14.03", name: "Tıp Bayramı", type: "special" },
    { date: "10.11", name: "Atatürk'ü Anma Günü", type: "special" },
    { date: "24.11", name: "Öğretmenler Günü", type: "special" }
  ];
};

export const isHoliday = (date: Date): Holiday | undefined => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const dateString = `${day}.${month}`;
  
  return getTurkishHolidays(date.getFullYear()).find(
    holiday => holiday.date === dateString
  );
};