import { Procedure, ProcedureType } from '../types';

const STORAGE_KEY = 'celikMedProcedures';

export const saveProcedures = (procedures: Procedure[]): void => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(procedures));
};

export const loadProcedures = (): Procedure[] => {
  const storedData = localStorage.getItem(STORAGE_KEY);
  return storedData ? JSON.parse(storedData) : [];
};

const extractNumber = (str: string): number => {
  const match = str.match(/\d+/);
  return match ? parseInt(match[0]) : Number.MAX_SAFE_INTEGER;
};

const isNumericRoom = (room: string): boolean => {
  return /^\d+$/.test(room);
};

const compareRoomNumbers = (a: string, b: string): number => {
  const aIsNumeric = isNumericRoom(a);
  const bIsNumeric = isNumericRoom(b);
  
  // Both are pure numbers
  if (aIsNumeric && bIsNumeric) {
    return parseInt(a) - parseInt(b);
  }
  
  // Both contain text
  if (!aIsNumeric && !bIsNumeric) {
    const aNum = extractNumber(a);
    const bNum = extractNumber(b);
    
    // If they have different numbers, sort by number
    if (aNum !== bNum) {
      return aNum - bNum;
    }
    
    // If they have the same number or no numbers, sort alphabetically
    return a.localeCompare(b);
  }
  
  // One is numeric, one contains text - numeric comes first
  return aIsNumeric ? -1 : 1;
};

export const getProceduresByDateAndType = (
  procedures: Procedure[],
  date: string,
  type: ProcedureType
): Procedure[] => {
  const filteredProcedures = procedures.filter(
    (procedure) => procedure.date === date && 
    (type === 'surgery' ? procedure.roomNumber !== undefined : procedure.roomNumber === undefined)
  );

  if (type === 'surgery') {
    return filteredProcedures.sort((a, b) => {
      if (!a.roomNumber || !b.roomNumber) return 0;
      return compareRoomNumbers(a.roomNumber, b.roomNumber);
    });
  } else {
    // Group by doctor and maintain original order within each group
    const doctorGroups = filteredProcedures.reduce((groups, procedure) => {
      if (!groups[procedure.doctor]) {
        groups[procedure.doctor] = [];
      }
      groups[procedure.doctor].push(procedure);
      return groups;
    }, {} as Record<string, Procedure[]>);

    // Sort doctors alphabetically and maintain procedure order within each group
    return Object.keys(doctorGroups)
      .sort((a, b) => a.localeCompare(b))
      .flatMap(doctor => doctorGroups[doctor]);
  }
};

export const addProcedure = (procedures: Procedure[], newProcedure: Procedure): Procedure[] => {
  const updatedProcedures = [...procedures, newProcedure];
  saveProcedures(updatedProcedures);
  return updatedProcedures;
};

export const removeProcedure = (procedures: Procedure[], id: string): Procedure[] => {
  const updatedProcedures = procedures.filter(procedure => procedure.id !== id);
  saveProcedures(updatedProcedures);
  return updatedProcedures;
};

export const updateProcedure = (procedures: Procedure[], editedProcedure: Procedure): Procedure[] => {
  const filteredProcedures = procedures.filter(p => p.id !== editedProcedure.id);
  const updatedProcedures = [...filteredProcedures, editedProcedure];
  saveProcedures(updatedProcedures);
  return updatedProcedures;
};