export interface Procedure {
  id: string;
  date: string;
  roomNumber?: string;
  doctor: string;
  procedureType: string;
  patientName: string;
  patientPhone: string;
  summary: string;
  notes: string;
}

export type ProcedureType = 'surgery' | 'endoColon';

export interface ProcedureFormData {
  roomNumber?: string;
  doctor: string;
  procedureType: string;
  patientName: string;
  patientPhone: string;
  summary: string;
  notes: string;
}

export const ENDO_PROCEDURES = {
  'Endoskopi': 'bg-green-100 text-green-800',
  'Kolonoskopi': 'bg-blue-100 text-blue-800',
  'Endo+Kolon': 'bg-purple-100 text-purple-800',
  'Rektoskopi': 'bg-orange-100 text-orange-800',
  'Poşoskopi': 'bg-pink-100 text-pink-800'
} as const;

export type EndoProcedureType = keyof typeof ENDO_PROCEDURES;

export interface User {
  username: string;
  isAuthenticated: boolean;
}